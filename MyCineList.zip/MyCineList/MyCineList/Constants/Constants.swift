//
//  Constants.swift
//  MyCineList
//
//  Created by Sumanth Maddela on 19/06/25.
//

import Foundation
struct Constants {
    
    struct Urls {
        static let trendingMoviesUrl = "https://api.themoviedb.org/3/trending/movie/day?language=en-US"
        static func playingMoviesUrl(forPage page: Int) -> String {
            return "https://api.themoviedb.org/3/movie/now_playing?language=en-US&page=\(page)"
        }
        static let imageBaseUrl = "https://image.tmdb.org/t/p/w500"
    }
    
    struct Tokens {
        static let accessToken = "Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIzOGU3NzFmMTQ1ZDgxYjNjZmQ0MDk3YjQzZDBiZjIxOCIsIm5iZiI6MTc1MDA2NDU2Ni42NjksInN1YiI6IjY4NGZkZGI2ODBhZDMwMTE5NjI5NTMxOSIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.S4srnuiFykUi0ThHWvl1eZRoGwHkGE2Vv4L11qO4psQ"
        
        static let appKey = "38e771f145d81b3cfd4097b43d0bf218"
    }
    
    struct Entity {
        static let trendingEntity = "TrendingEntity"
        static let playingEntity = "PlayingEntity"
        static let movieEntity = "MovieEntity"
    }
}
