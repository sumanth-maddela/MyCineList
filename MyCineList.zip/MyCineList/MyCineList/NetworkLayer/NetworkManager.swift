//
//  NetworkManager.swift
//  MyCineList
//
//  Created by Sumanth Maddela on 19/06/25.
//

import Foundation
import UIKit

protocol NetworkProtocol {
    func fetchData<T: Decodable>(request: NetworkRequest, completion: @escaping (Result<T, Error>) -> Void)
}

enum NetworkError: Error {
    case inValidUrl(Error)
    case emptyData
    case decodingFailed(Error)
}

class NetworkManager: NetworkProtocol {
    
    static let shared = NetworkManager()
    
    private init() { }
    
    
    func fetchData<T: Decodable>(request: NetworkRequest, completion: @escaping (Result<T, Error>) -> Void) {
        var urlRequest = URLRequest(url: request.url)
        urlRequest.httpMethod = request.method
        request.headers.forEach { key, value in
            urlRequest.setValue(value, forHTTPHeaderField: key)
        }
        
        URLSession.shared.dataTask(with: urlRequest) { data, response, error in
            if let error = error {
                completion(.failure(NetworkError.inValidUrl(error)))
                return
            }
            
            guard let data = data else {
                completion(.failure(NetworkError.emptyData))
                return
            }
            
            do {
                let decoded = try JSONDecoder().decode(T.self, from: data)
                completion(.success(decoded))
            } catch {
                completion(.failure(NetworkError.decodingFailed(error)))
            }
        }.resume()
    }
    
    //Downloaded image is saved in the cache here
    func downloadImage(urlString: String?, completion: @escaping(UIImage?)->Void) {
        guard let urlString = urlString, let url = URL(string: urlString) else {
            completion(nil)
            return
        }
        
        if let image = CacheManager.shared.getImage(urlString)  {
            completion(image)
            return
        }
        
        URLSession.shared.dataTask(with: url) {(data,_,error) in
            if let error = error {
                completion(nil)
                return
            }
            
            guard let data = data, let image = UIImage(data: data) else {
                completion(nil)
                return
            }
            CacheManager.shared.saveImage(urlString, image)
            
            completion(image)
        }.resume()
    }

}


