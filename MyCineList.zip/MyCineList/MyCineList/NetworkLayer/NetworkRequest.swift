//
//  NetworkRequest.swift
//  MyCineList
//
//  Created by Sumanth Maddela on 19/06/25.
//

import Foundation

struct NetworkRequest {
    let url: URL
    let method: String
    let headers: [String: String]
    
    //Provided default values since only two apis used and both use same httpMethpod and headers
    static var defaultHeaders: [String: String] {
        return [
            "Authorization": Constants.Tokens.accessToken,
            "accept": "application/json"
        ]
    }
    
    init(url: URL,
         method: String = "GET",
         headers: [String: String] = NetworkRequest.defaultHeaders) {
        self.url = url
        self.method = method
        self.headers = headers
    }

}
