//
//  TrendingMovies.swift
//  MyCineList
//
//  Created by Sumanth Maddela on 16/06/25.
//

import Foundation


struct TrendingMovies: Codable {
    let page: Int
    let results: [TrendingResult]
    let totalPages, totalResults: Int

    enum CodingKeys: String, CodingKey {
        case page, results
        case totalPages = "total_pages"
        case totalResults = "total_results"
    }
}


struct TrendingResult: Codable {
    let backdropPath: String
    let id: Int
    let title, originalTitle, overview, posterPath: String
    let mediaType: MediaType
    let adult: Bool
    let originalLanguage: OriginalLang
    let genreIDS: [Int]
    let popularity: Double
    let releaseDate: String
    let video: Bool
    let voteAverage: Double
    let voteCount: Int

    enum CodingKeys: String, CodingKey {
        case backdropPath = "backdrop_path"
        case id, title
        case originalTitle = "original_title"
        case overview
        case posterPath = "poster_path"
        case mediaType = "media_type"
        case adult
        case originalLanguage = "original_language"
        case genreIDS = "genre_ids"
        case popularity
        case releaseDate = "release_date"
        case video
        case voteAverage = "vote_average"
        case voteCount = "vote_count"
    }
}

enum MediaType: String, Codable {
    case movie = "movie"
}

enum OriginalLang: String, Codable {
    case en = "en"
    case zh = "zh"
    case af = "af"
    case es = "es"
}


//curl --request GET \
//     --url 'https://api.themoviedb.org/3/trending/movie/day?language=en-US' \
//     --header 'Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIzOGU3NzFmMTQ1ZDgxYjNjZmQ0MDk3YjQzZDBiZjIxOCIsIm5iZiI6MTc1MDA2NDU2Ni42NjksInN1YiI6IjY4NGZkZGI2ODBhZDMwMTE5NjI5NTMxOSIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.S4srnuiFykUi0ThHWvl1eZRoGwHkGE2Vv4L11qO4psQ' \
//     --header 'accept: application/json'

