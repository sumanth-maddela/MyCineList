//
//  PlayingMovies.swift
//  MyCineList
//
//  Created by Sumanth Maddela on 16/06/25.
//

import Foundation

struct PlayingMovies: Codable {
    let dates: Dates
    let page: Int
    let results: [PlayingResults]
    let totalPages: Int
    let totalResults: Int

    enum CodingKeys: String, CodingKey {
        case dates, page, results
        case totalPages = "total_pages"
        case totalResults = "total_results"
    }
}

struct Dates: Codable {
    let maximum, minimum: String
}

struct PlayingResults: Codable {
    let adult: Bool
    let backdropPath: String
    let genreIDS: [Int]
    let id: Int
    let originalLanguage: OriginalLanguage
    let originalTitle: String
    let overview: String
    let popularity: Double
    let posterPath: String
    let releaseDate: String
    let title: String
    let video: Bool
    let voteAverage: Double
    let voteCount: Int

    enum CodingKeys: String, CodingKey {
        case adult
        case backdropPath = "backdrop_path"
        case genreIDS = "genre_ids"
        case id
        case originalLanguage = "original_language"
        case originalTitle = "original_title"
        case overview, popularity
        case posterPath = "poster_path"
        case releaseDate = "release_date"
        case title, video
        case voteAverage = "vote_average"
        case voteCount = "vote_count"
    }
}

enum OriginalLanguage: String, Codable {
    case bn = "bn"
    case en = "en"
    case fr = "fr"
    case no = "no"
    case es = "es"
    case zh = "zh"
    case lv = "lv"
    case ar = "ar"
    case af = "af"
    case nl = "nl"
    case tl = "tl"
    case ko = "ko"
    case it = "it"
    case hi = "hi"
    case ja = "ja"
    case cn = "cn"
}







//curl --request GET \
//     --url 'https://api.themoviedb.org/3/movie/now_playing?language=en-US&page=1' \
//     --header 'Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIzOGU3NzFmMTQ1ZDgxYjNjZmQ0MDk3YjQzZDBiZjIxOCIsIm5iZiI6MTc1MDA2NDU2Ni42NjksInN1YiI6IjY4NGZkZGI2ODBhZDMwMTE5NjI5NTMxOSIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.S4srnuiFykUi0ThHWvl1eZRoGwHkGE2Vv4L11qO4psQ' \
//     --header 'accept: application/json'

