//
//  MovieDetailModel.swift
//  MyCineList
//
//  Created by Sumanth Maddela on 22/06/25.
//

import Foundation

//Used just for simplified version MovieModel , used across the application.
struct MovieDetailModel {
    let title: String
    let releaseDate: String
    let rating: Double
    let overview: String
    let imageURL: String
}
