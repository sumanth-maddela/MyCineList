//
//  MovieModel.swift
//  MyCineList
//
//  Created by Sumanth Maddela on 22/06/25.
//

import Foundation

struct MovieModel {
    let id: Int
    let title: String
    let releaseDate: String
    let rating: Double
    let imageURL: String
    let overview: String
    let isTrending: Bool
    let isPlaying: Bool
    var isBookmarked: Bool
}
