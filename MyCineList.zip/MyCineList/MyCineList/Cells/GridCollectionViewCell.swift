//
//  GridCollectionViewCell.swift
//  MyCineList
//
//  Created by Sumanth Maddela on 19/06/25.
//

import UIKit

protocol GridCollectionViewCellDelegate: AnyObject {
    func didSelectMovie(_ movie: MovieDetailModel)
}

//FOR THE HORIZONTAL SCROLL
class GridCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var collectionView: UICollectionView!
    
    static let identifier = "GridCollectionViewCell"
    
    var viewModel = HomeViewModel()
    var category: MovieCategory?
    weak var delegate: GridCollectionViewCellDelegate?
    
    private var movies: [MovieModel] = []

    override func awakeFromNib() {
        super.awakeFromNib()
        registerCell()
    }

    func registerCell() {
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.register(UINib(nibName: "MovieCollectionViewCell", bundle: nil),
                                forCellWithReuseIdentifier: MovieCollectionViewCell.identifier)
    }

    func configure(for category: MovieCategory) {
        self.category = category

        viewModel.onDataFetch = { [weak self] in
            guard let self = self else { return }
            self.movies = self.viewModel.getMovies(for: category)

            DispatchQueue.main.async {
                self.collectionView.reloadData()
            }
        }

        let urlString = category == .trending ? Constants.Urls.trendingMoviesUrl : Constants.Urls.playingMoviesUrl(forPage: 1)
        guard let url = URL(string: urlString) else { return }
        let request = NetworkRequest(url: url)
        viewModel.fetchMoviesData(category: category, request: request)
    }
}

extension GridCollectionViewCell: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return movies.count
    }

    func collectionView(_ collectionView: UICollectionView,
                        cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: MovieCollectionViewCell.identifier,
                                                            for: indexPath) as? MovieCollectionViewCell else {
            return UICollectionViewCell()
        }

        let movie = movies[indexPath.item]
        let movieModel = MovieDetailModel(title: movie.title,
                                          releaseDate: movie.releaseDate,
                                          rating: movie.rating,
                                          overview: movie.overview,
                                          imageURL: movie.imageURL)
        cell.movie = movieModel
        cell.configure(with: movieModel)
        cell.setupUI()
        cell.updateBookmarkState()
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let movie = movies[indexPath.item]
        let movieDetail = MovieDetailModel(title: movie.title,
                                     releaseDate: movie.releaseDate,
                                     rating: movie.rating,
                                    overview: movie.overview,
                                    imageURL: movie.imageURL)
        print("Movie Detail: \(movieDetail)")
        delegate?.didSelectMovie(movieDetail)
    }

    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = (collectionView.frame.width - 12) / 2
        return CGSize(width: width, height: width * 1.5)
    }
}

extension GridCollectionViewCell: UIScrollViewDelegate {
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        guard category == .nowPlaying else { return }

        let offsetY = scrollView.contentOffset.y
        let contentHeight = scrollView.contentSize.height
        let height = scrollView.frame.size.height

        if offsetY > contentHeight - height * 1.2 {
            viewModel.loadMoreNowPlayingIfNeeded()
        }
    }
}
