//
//  MovieCollectionViewCell.swift
//  MyCineList
//
//  Created by Sumanth Maddela on 19/06/25.
//

import UIKit

//FOR THE VERTICAL SCROLL --> MOVIE CELL
class MovieCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var baseView: UIView!
    @IBOutlet weak var movieImage: UIImageView!
    @IBOutlet weak var movieTitle: UILabel!
    @IBOutlet weak var movieRating: UILabel!
    @IBOutlet weak var bookmarkBtn: UIButton!
    
    static let identifier = "MovieCollectionViewCell"
    
    var movie: MovieDetailModel?
    var onBookmarkTapped: (() -> Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setupUI()
    }

    var isBookmarked: Bool = false {
        didSet {
            let imageName = isBookmarked ? "bookmark.fill" : "bookmark"
            bookmarkBtn.setImage(UIImage(systemName: imageName), for: .normal)
        }
    }

    @IBAction func bookmarkBtnAction(_ sender: UIButton) {
        guard let movie = movie else { return }
        
        let isAlreadyBookmarked = CoreDataManager.shared.isMovieInWatchlist(title: movie.title)
        
        if isAlreadyBookmarked {
            CoreDataManager.shared.removeFromWatchlist(title: movie.title)
        } else {
            CoreDataManager.shared.saveToWatchlist(movie)
        }

        updateBookmarkState()
        onBookmarkTapped?()
    }

    func updateBookmarkState() {
        guard let movie = movie else { return }
        let isAlreadyBookmarked = CoreDataManager.shared.isMovieInWatchlist(title: movie.title)
        isBookmarked = isAlreadyBookmarked
    }

    func configure(with model: MovieDetailModel) {
        self.movie = model
        
        movieTitle.text = "\(model.title.uppercased()) (\(model.releaseDate.prefix(4)))"
        movieRating.text = "⭐️ \(String(format: "%.1f", model.rating))"
        
        let imageUrl = Constants.Urls.imageBaseUrl + model.imageURL
        NetworkManager.shared.downloadImage(urlString: imageUrl) { [weak self] image in
            DispatchQueue.main.async {
                self?.movieImage.image = image
            }
        }

        updateBookmarkState()
    }

    func setupUI() {
        movieImage.layer.cornerRadius = 12
        movieImage.clipsToBounds = true

        baseView.layer.cornerRadius = 12
        baseView.layer.shadowColor = UIColor.black.cgColor
        baseView.layer.shadowOpacity = 0.1
        baseView.layer.shadowOffset = CGSize(width: 0, height: 3)
        baseView.layer.shadowRadius = 6
        baseView.layer.masksToBounds = false
    }
}
