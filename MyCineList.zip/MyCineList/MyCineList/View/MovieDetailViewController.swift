//
//  MovieDetailViewController.swift
//  MyCineList
//
//  Created by Sumanth Maddela on 21/06/25.
//

import UIKit

class MovieDetailViewController: UIViewController {

    var movie: MovieDetailModel?
    
    @IBOutlet weak var movieImage: UIImageView!
    @IBOutlet weak var movieTitleLabel: UILabel!
    @IBOutlet weak var releaseDateLabel: UILabel!
    @IBOutlet weak var ratingLabel: UILabel!
    @IBOutlet weak var shareButton: UIButton!
    @IBOutlet weak var overviewLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    func setupUI() {
        shareButton.layer.cornerRadius = shareButton.frame.width/2
        shareButton.backgroundColor = .white
        guard let movie = movie else {
            return
        }
        movieTitleLabel.text = movie.title.uppercased()
        releaseDateLabel.text = DateConvertor.convertToReadableFormat(from: movie.releaseDate)
        ratingLabel.text = "⭐️ \(String(format: "%.1f", movie.rating))"
        overviewLabel.text = movie.overview
        
        NetworkManager.shared.downloadImage(urlString: Constants.Urls.imageBaseUrl+movie.imageURL) { image in
            DispatchQueue.main.async {
                self.movieImage.image = image
            }
        }
    }

    @IBAction func shareBtnAction(_ sender: Any) {
        print("Tapped!!")
        shareMovie()
    }
    
    @objc func shareMovie() {
        guard let imagePath = movie?.imageURL else { return }
        let fullImageURL = Constants.Urls.imageBaseUrl + imagePath

        let activityVC = UIActivityViewController(activityItems: [fullImageURL], applicationActivities: nil)
        activityVC.popoverPresentationController?.sourceView = self.view

        present(activityVC, animated: true, completion: nil)
    }
    
    
}
