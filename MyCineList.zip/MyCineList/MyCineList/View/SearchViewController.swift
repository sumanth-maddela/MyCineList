//
//  SearchViewController.swift
//  MyCineList
//
//  Created by Sumanth Maddela on 18/06/25.
//

import UIKit

class SearchViewController: UIViewController {

    @IBOutlet weak var collectionView: UICollectionView!
    let searchController = UISearchController()

    var allMovies: [MovieModel] = []
    var filteredMovies: [MovieModel] = []
    var debounceWorkItem: DispatchWorkItem?

    override func viewDidLoad() {
        super.viewDidLoad()
        fetchDataFromCD()
        setupUI()
        registerCell()
        collectionView.reloadData()
    }

    func fetchDataFromCD() {
        let allCoreDataMovies = CoreDataManager.shared.fetchMoviesFromCD()
        let uniqueMovies = Dictionary(grouping: allCoreDataMovies, by: { $0.title })
            .compactMap { $0.value.first }
        allMovies = uniqueMovies
        filteredMovies = []
    }


    func setupUI() {
        title = "SEARCH"
        navigationItem.searchController = searchController
        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.white]
        searchController.searchResultsUpdater = self
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchBar.searchTextField.textColor = .white
        searchController.searchBar.searchTextField.attributedPlaceholder = NSAttributedString(
            string: "Search Movies",
            attributes: [.foregroundColor: UIColor.lightGray]
        )
        searchController.searchBar.tintColor = .white
    }

    func registerCell() {
        definesPresentationContext = true

        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.register(UINib(nibName: "MovieCollectionViewCell", bundle: nil),
                                forCellWithReuseIdentifier: "MovieCollectionViewCell")
    }
}

extension SearchViewController: UISearchResultsUpdating {
    
    //Optimised the search using DispatchWorkItem
    func updateSearchResults(for searchController: UISearchController) {
        debounceWorkItem?.cancel()

        let workItem = DispatchWorkItem { [weak self] in
            self?.performSearch()
        }

        debounceWorkItem = workItem
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: workItem)
    }

    private func performSearch() {
        guard let searchText = searchController.searchBar.text?.lowercased(), !searchText.isEmpty else {
            filteredMovies = []
            collectionView.reloadData()
            return
        }

        filteredMovies = allMovies.filter {
            $0.title.lowercased().contains(searchText)
        }

        collectionView.reloadData()
    }
}

extension SearchViewController: UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return filteredMovies.count
    }

    func collectionView(_ collectionView: UICollectionView,
                        cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MovieCollectionViewCell",
                                                            for: indexPath) as? MovieCollectionViewCell else {
            return UICollectionViewCell()
        }

        let movie = filteredMovies[indexPath.item]

        let movieDetail = MovieDetailModel(title: movie.title,
                                           releaseDate: movie.releaseDate,
                                           rating: movie.rating,
                                           overview: movie.overview,
                                           imageURL: movie.imageURL)

        cell.movie = movieDetail
        cell.configure(with: movieDetail)
        cell.setupUI()
        cell.updateBookmarkState()

        return cell
    }

    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = (collectionView.frame.width - 16) / 2
        return CGSize(width: width, height: width * 1.5)
    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let selectedMovie = filteredMovies[indexPath.item]

        let movieDetail = MovieDetailModel(title: selectedMovie.title,
                                           releaseDate: selectedMovie.releaseDate,
                                           rating: selectedMovie.rating,
                                           overview: selectedMovie.overview,
                                           imageURL: selectedMovie.imageURL)

        let detailVC = MovieDetailViewController()
        detailVC.movie = movieDetail
        detailVC.hidesBottomBarWhenPushed = true
        navigationController?.pushViewController(detailVC, animated: true)
    }
}
