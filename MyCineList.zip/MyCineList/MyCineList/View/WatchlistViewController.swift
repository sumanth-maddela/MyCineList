//
//  WatchlistViewController.swift
//  MyCineList
//
//  Created by Sumanth Maddela on 18/06/25.
//

import UIKit

class WatchlistViewController: UIViewController {
    
    @IBOutlet weak var collectionView: UICollectionView!
    var watchlist: [MovieDetailModel] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        registerCell()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        loadWatchlist()
    }
    
    func setupUI() {
        title = "WATCHLIST"
        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.white]
    }
    
    func registerCell() {
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.register(UINib(nibName: "MovieCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: MovieCollectionViewCell.identifier)
        loadWatchlist()
    }
    
    
    func loadWatchlist() {
        watchlist = CoreDataManager.shared.fetchWatchlist()
        collectionView.reloadData()
    }
    
    func fetchWatchlist() {
        watchlist = CoreDataManager.shared.fetchWatchlist()
        collectionView.reloadData()
    }

}

extension WatchlistViewController : UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return watchlist.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: MovieCollectionViewCell.identifier, for: indexPath) as? MovieCollectionViewCell else {
            return UICollectionViewCell()
        }
        let movie = watchlist[indexPath.item]
        let movieModel = MovieDetailModel(title: movie.title,
                                          releaseDate: movie.releaseDate,
                                          rating: movie.rating,
                                          overview: movie.overview,
                                          imageURL: movie.imageURL)
        cell.configure(with: movieModel)
        cell.onBookmarkTapped = { [weak self] in
            self?.fetchWatchlist()
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = (collectionView.frame.width - 12) / 2
        return CGSize(width: width, height: width * 1.5)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let detailVC = MovieDetailViewController()
        let movie = watchlist[indexPath.item]
        let movieModel = MovieDetailModel(title: movie.title,
                                          releaseDate: movie.releaseDate,
                                          rating: movie.rating,
                                          overview: movie.overview,
                                          imageURL: movie.imageURL)
        detailVC.movie = movieModel
        detailVC.hidesBottomBarWhenPushed = true
        navigationController?.pushViewController(detailVC, animated: true)
    }
}



