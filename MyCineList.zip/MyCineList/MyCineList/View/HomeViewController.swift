//
//  ViewController.swift
//  MyCineList
//
//  Created by Sumanth Maddela on 16/06/25.
//

import UIKit

//TOW CATEGORIES FOR TWO ENDPOINTS
enum MovieCategory: Int, CaseIterable{
    case trending
    case nowPlaying
}

class HomeViewController: UIViewController {
    
    @IBOutlet weak var buttonsStack: UIStackView!
    @IBOutlet weak var trendingButton: UIButton!
    @IBOutlet weak var playingButton: UIButton!
    @IBOutlet weak var barView: UIView!
    @IBOutlet weak var collectionView: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "MOVIES"
        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.white]
        registerCell()
        setupUI()
        configureCollectionViewLayout()
        updateButtonStates(selected: .trending)
        barView.isHidden = true
    }
    
    @IBAction func trendingBtnAction(_ sender: Any) {
        updateButtonStates(selected: .trending)
        let indexPath = IndexPath(item: MovieCategory.trending.rawValue, section: 0)
        collectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
    }

    @IBAction func nowPlayingBtnAction(_ sender: Any) {
        updateButtonStates(selected: .nowPlaying)
        let indexPath = IndexPath(item: MovieCategory.nowPlaying.rawValue, section: 0)
        collectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
    }

    func updateButtonStates(selected: MovieCategory) {
        switch selected {
        case .trending:
            trendingButton.backgroundColor = .systemGray
            trendingButton.setTitleColor(.white, for: .normal)
            
            playingButton.backgroundColor = .clear
            playingButton.setTitleColor(.black, for: .normal)
        case .nowPlaying:
            playingButton.backgroundColor = .systemGray
            playingButton.setTitleColor(.white, for: .normal)
            
            trendingButton.backgroundColor = .clear
            trendingButton.setTitleColor(.black, for: .normal)
        }
    }


    func setupUI() {
        trendingButton.layer.cornerRadius = 24.0
        playingButton.layer.cornerRadius = 24.0
        buttonsStack.layer.borderWidth = 1
        buttonsStack.layer.borderColor = UIColor.black.cgColor
        buttonsStack.layer.cornerRadius = 24
    }
    
    func registerCell() {
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.showsHorizontalScrollIndicator = false
        collectionView.register(UINib(nibName: "GridCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: GridCollectionViewCell.identifier)
    }
    
    func configureCollectionViewLayout() {
        if let layout = collectionView.collectionViewLayout as? UICollectionViewFlowLayout {
            layout.scrollDirection = .horizontal
            layout.minimumLineSpacing = 0
            layout.minimumInteritemSpacing = 0
        }
    }

}

extension HomeViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return MovieCategory.allCases.count 
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: GridCollectionViewCell.identifier,
                                                            for: indexPath) as? GridCollectionViewCell,
              let category = MovieCategory(rawValue: indexPath.item) else {
            return UICollectionViewCell()
        }
        cell.delegate = self
        cell.configure(for: category)
        return cell
    }

    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        return collectionView.bounds.size
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let page = Int(scrollView.contentOffset.x / scrollView.frame.width)
        
        if let category = MovieCategory(rawValue: page) {
            updateButtonStates(selected: category)
        }
    }

}

extension HomeViewController: GridCollectionViewCellDelegate {
    func didSelectMovie(_ movie: MovieDetailModel) {
        let movieDetailVC = MovieDetailViewController(nibName: String(describing: MovieDetailViewController.self), 
                                                      bundle: nil)
        movieDetailVC.movie = movie
        movieDetailVC.hidesBottomBarWhenPushed = true
        navigationController?.pushViewController(movieDetailVC, animated: true)
    }
}


