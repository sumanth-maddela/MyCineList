//
//  CoreDataManager.swift
//  MyCineList
//
//  Created by Sumanth Maddela on 16/06/25.
//

import Foundation
import CoreData

class CoreDataManager {
    static let shared = CoreDataManager()
    
    private init() { }
    
    
    lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "MyCineList")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()
    
    var context: NSManagedObjectContext {
        return persistentContainer.viewContext
    }

    func saveContext () {
        let context = persistentContainer.viewContext
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }

    //Created three entities seperate entities for Trending , Now Playing and Bookmarked Movies but later optimized with one enitiy --> MovieEntity
    
    //NOT USING
    func saveTrendingMovies(_ movies: [TrendingResult]) {
        clearEntity(Constants.Entity.trendingEntity)

        for movie in movies {
            let entity = TrendingEntity(context: context)
            entity.id = Int64(movie.id)
            entity.title = movie.title
            entity.imageURL = movie.posterPath
            entity.releaseDate = movie.releaseDate
            entity.voteAverage = movie.voteAverage
            entity.overview = movie.overview
        }

        saveContext()
    }

    //NOT USING
    func saveNowPlayingMovies(_ movies: [PlayingResults]) {
        clearEntity(Constants.Entity.playingEntity)

        for movie in movies {
            let entity = PlayingEntity(context: context)
            entity.id = Int64(movie.id)
            entity.title = movie.title
            entity.imageURL = movie.posterPath
            entity.releaseDate = movie.releaseDate
            entity.voteAverage = movie.voteAverage
            entity.overview = movie.overview
        }
        saveContext()
    }
    
    func saveMoviesinCD(_ movies: [MovieModel]) {
        clearEntity(Constants.Entity.playingEntity)
        
        for movie in movies {
            let entity = MovieEntity(context: context)
            entity.id = Int64(movie.id)
            entity.imageURL = movie.imageURL
            entity.title = movie.title
            entity.releaseDate = movie.releaseDate
            entity.overview = movie.overview
            entity.rating = movie.rating
            entity.isBookmarked = movie.isBookmarked
            entity.isTrending = movie.isTrending
            entity.isPlaying = movie.isPlaying
            entity.isBookmarked = movie.isBookmarked
        }
    }
    
    func fetchMoviesFromCD() -> [MovieModel] {
        let request: NSFetchRequest<MovieEntity> = MovieEntity.fetchRequest()
        do {
            let entities = try context.fetch(request)
            return entities.map {
                MovieModel(id: Int($0.id),
                           title: $0.title ?? "",
                           releaseDate: $0.releaseDate ?? "",
                           rating: $0.rating ,
                           imageURL: $0.imageURL ?? "",
                           overview: $0.overview ?? "",
                           isTrending: $0.isTrending ,
                           isPlaying:  $0.isPlaying ,
                           isBookmarked:  $0.isBookmarked )
            }
        } catch {
            print("Error fetching trending from Core Data: \(error)")
            return []
        }
    }
    
    //NOT USING IT
    func fetchTrendingMovies() -> [TrendingResult] {
        let request: NSFetchRequest<TrendingEntity> = TrendingEntity.fetchRequest()
        do {
            let entities = try context.fetch(request)
            return entities.map {
                TrendingResult(
                    backdropPath: "",
                    id: Int($0.id),
                    title: $0.title ?? "",
                    originalTitle: $0.title ?? "",
                    overview: $0.overview ?? "",
                    posterPath: $0.imageURL ?? "",
                    mediaType: .movie,
                    adult: false,
                    originalLanguage: .en,
                    genreIDS: [],
                    popularity: 0.0,
                    releaseDate: $0.releaseDate ?? "",
                    video: false,
                    voteAverage: $0.voteAverage,
                    voteCount: 0
                )
            }
        } catch {
            print("Error fetching trending from Core Data: \(error)")
            return []
        }
    }

    //NOT USING
    func fetchNowPlayingMovies() -> [PlayingResults] {
        let request: NSFetchRequest<PlayingEntity> = PlayingEntity.fetchRequest()
        do {
            let entities = try context.fetch(request)
            return entities.map {
                PlayingResults(
                    adult: false,
                    backdropPath: "",
                    genreIDS: [],
                    id: Int($0.id),
                    originalLanguage: .en,
                    originalTitle: $0.title ?? "",
                    overview: $0.overview ?? "",
                    popularity: 0.0,
                    posterPath: $0.imageURL ?? "",
                    releaseDate: $0.releaseDate ?? "",
                    title: $0.title ?? "",
                    video: false,
                    voteAverage: $0.voteAverage,
                    voteCount: 0
                )
            }
        } catch {
            print("Error fetching now playing from Core Data: \(error)")
            return []
        }
    }

    
    private func clearEntity(_ entityName: String) {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: entityName)
        let deleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)

        do {
            try context.execute(deleteRequest)
        } catch {
            print("Failed to clear Core Data entity \(entityName): \(error)")
        }
    }

}

extension CoreDataManager {
    
    func saveToWatchlist(_ movie: MovieDetailModel) {
        guard !isMovieInWatchlist(title: movie.title) else { return }

        let entity = MovieEntity(context: context)
        entity.title = movie.title
        entity.releaseDate = movie.releaseDate
        entity.rating = movie.rating
        entity.overview = movie.overview
        entity.imageURL = movie.imageURL
        entity.isBookmarked = true

        saveContext()
    }

    func removeFromWatchlist(title: String) {
        let request: NSFetchRequest<MovieEntity> = MovieEntity.fetchRequest()
        request.predicate = NSPredicate(format: "title == %@ AND isBookmarked == true", title)

        if let results = try? context.fetch(request), let movie = results.first {
            context.delete(movie)
            saveContext()
        }
    }

    func fetchWatchlist() -> [MovieDetailModel] {
        let request: NSFetchRequest<MovieEntity> = MovieEntity.fetchRequest()
        request.predicate = NSPredicate(format: "isBookmarked == true")

        let results = (try? context.fetch(request)) ?? []

        return results.map {
            MovieDetailModel(
                title: $0.title ?? "",
                releaseDate: $0.releaseDate ?? "",
                rating: $0.rating,
                overview: $0.overview ?? "",
                imageURL: $0.imageURL ?? ""
            )
        }
    }

    func isMovieInWatchlist(title: String) -> Bool {
        let request: NSFetchRequest<MovieEntity> = MovieEntity.fetchRequest()
        request.predicate = NSPredicate(format: "title == %@ AND isBookmarked == true", title)
        let count = (try? context.count(for: request)) ?? 0
        return count > 0
    }
}

