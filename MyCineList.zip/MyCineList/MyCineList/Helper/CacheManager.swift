//
//  CacheManager.swift
//  MyCineList
//
//  Created by Sumanth Maddela on 20/06/25.
//

import Foundation
import UIKit

//Cache Implementation
class CacheManager {
    
    static let shared = CacheManager()
    private init() { }
    var cache = NSCache<NSString,UIImage>()
    
    func saveImage(_ key: String, _ image: UIImage) {
        cache.setObject(image, forKey: key as NSString)
    }
    
    func getImage(_ key: String) -> UIImage? {
        guard let image = cache.object(forKey: key as NSString) else {
            return nil
        }
        return image
    }
    
}
