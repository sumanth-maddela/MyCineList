//
//  DateConvertor.swift
//  MyCineList
//
//  Created by Sumanth Maddela on 22/06/25.
//

import Foundation

//To format the release date 
class DateConvertor {
    
    static func convertToReadableFormat(from input: String) -> String {
        let inputFormatter = DateFormatter()
        inputFormatter.dateFormat = "yyyy-MM-dd"

        let outputFormatter = DateFormatter()
        outputFormatter.dateFormat = "MMMM dd, yyyy"

        if let date = inputFormatter.date(from: input) {
            return outputFormatter.string(from: date)
        } else {
            return input
        }
    }
}
