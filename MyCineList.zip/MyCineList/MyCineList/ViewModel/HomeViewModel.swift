//
//  HomeViewModel.swift
//  MyCineList
//
//  Created by Sumanth Maddela on 19/06/25.
//

import Foundation

class HomeViewModel {

    var onDataFetch: (() -> Void)?

    var trendingResults: [MovieModel] = []
    var nowPlayingResults: [MovieModel] = []

    private(set) var nowPlayingCurrentPage = 1
    private var nowPlayingTotalPages = 1
    private var isLoadingNowPlaying = false

    func fetchMoviesData(category: MovieCategory, request: NetworkRequest, append: Bool = false) {
        switch category {
        case .trending:
            NetworkManager.shared.fetchData(request: request) { [weak self] (result: Result<TrendingMovies, Error>) in
                guard let self = self else { return }
                switch result {
                case .success(let data):
                    self.trendingResults = data.results.map {
                        MovieModel(id: $0.id,
                                   title: $0.title,
                                   releaseDate: $0.releaseDate,
                                   rating: $0.voteAverage,
                                   imageURL: $0.posterPath,
                                   overview: $0.overview,
                                   isTrending: true,
                                   isPlaying: false,
                                   isBookmarked: false)
                    }
                    CoreDataManager.shared.saveMoviesinCD(self.trendingResults)
                    self.onDataFetch?()

                case .failure(let error):
                    self.retrieveTrendingFromCoreData()
                    print("Trending Error: \(error)")
                }
            }

        case .nowPlaying:
            guard !isLoadingNowPlaying else { return }
            isLoadingNowPlaying = true

            NetworkManager.shared.fetchData(request: request) { [weak self] (result: Result<PlayingMovies, Error>) in
                guard let self = self else { return }
                self.isLoadingNowPlaying = false

                switch result {
                case .success(let data):
                    self.nowPlayingTotalPages = data.totalPages
                    self.nowPlayingCurrentPage = data.page + 1

                    let fetchedModels = data.results.map {
                        MovieModel(id: $0.id,
                                   title: $0.title,
                                   releaseDate: $0.releaseDate,
                                   rating: $0.voteAverage,
                                   imageURL: $0.posterPath,
                                   overview: $0.overview,
                                   isTrending: false,
                                   isPlaying: true,
                                   isBookmarked: false)
                    }

                    if append {
                        self.nowPlayingResults.append(contentsOf: fetchedModels)
                    } else {
                        self.nowPlayingResults = fetchedModels
                    }

                    CoreDataManager.shared.saveMoviesinCD(self.nowPlayingResults)
                    self.onDataFetch?()

                case .failure(let error):
                    self.retrievePlayingFromCoreData()
                    print("Now Playing Error: \(error)")
                }
            }
        }
    }

    func shouldLoadMoreNowPlaying() -> Bool {
        return nowPlayingCurrentPage <= nowPlayingTotalPages && !isLoadingNowPlaying
    }

    func loadMoreNowPlayingIfNeeded() {
        guard shouldLoadMoreNowPlaying(),
              let url = nextPageURL(for: .nowPlaying) else { return }

        let request = NetworkRequest(url: url)
        fetchMoviesData(category: .nowPlaying, request: request, append: true)
    }

    func getMovies(for category: MovieCategory) -> [MovieModel] {
        switch category {
        case .trending:
            return trendingResults
        case .nowPlaying:
            return nowPlayingResults
        }
    }

    func nextPageURL(for category: MovieCategory) -> URL? {
        guard category == .nowPlaying else { return nil }
        let urlString =  Constants.Urls.playingMoviesUrl(forPage: nowPlayingCurrentPage)
        let url = URL(string: urlString)
        return url
    }

    private func retrieveTrendingFromCoreData() {
        trendingResults = CoreDataManager.shared.fetchMoviesFromCD().filter { $0.isTrending }
        onDataFetch?()
    }

    private func retrievePlayingFromCoreData() {
        nowPlayingResults = CoreDataManager.shared.fetchMoviesFromCD().filter { $0.isPlaying }
        onDataFetch?()
    }
}
